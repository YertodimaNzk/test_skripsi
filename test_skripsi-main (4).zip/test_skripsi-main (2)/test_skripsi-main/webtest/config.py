# MySQL database configuration
mysql_config = {
    "user": "root",
    "password": "",
    "host": "127.0.0.1",
    "port": "3306",
    "database": "test_skripsi",
}
    